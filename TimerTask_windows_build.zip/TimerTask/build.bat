@echo off
chcp 65001 >nul
REM ============================================================
REM  Сборка TimerTask.exe для Windows 10 (двойной клик)
REM  Требуется: Python 3.8+ с https://python.org ("Add to PATH")
REM ============================================================
setlocal
cd /d "%~dp0"

echo [1/3] Проверка Python...
python --version >nul 2>&1 || (echo ! ОШИБКА: Python не найден. Установите с python.org и отметьте "Add Python to PATH" && pause & exit /b 1)

echo [2/3] Установка PyInstaller...
python -m pip install --quiet --upgrade pyinstaller || (echo ! ОШИБКА установки pyinstaller && pause & exit /b 1)

echo [3/3] Сборка EXE (onefile, без консольного окна)...
python -m PyInstaller --clean --noconfirm --onefile --windowed --name TimerTask ^
    --hidden-import tkinter --hidden-import tkinter.ttk --hidden-import tkinter.messagebox ^
    timer_task.py

if exist dist\TimerTask.exe (
    echo.
    echo ==============================================
    echo  ГОТОВО!  %cd%\dist\TimerTask.exe
    echo ==============================================
) else (
    echo ! ОШИБКА сборки. Смотрите сообщения выше.
)
pause
