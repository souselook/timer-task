# Альтернатива: сборка через PowerShell
Set-Location $PSScriptRoot
python -m pip install --upgrade pyinstaller
python -m PyInstaller --clean --noconfirm --onefile --windowed --name TimerTask `
    --hidden-import tkinter --hidden-import tkinter.ttk --hidden-import tkinter.messagebox `
    timer_task.py
if (Test-Path dist\TimerTask.exe) { Write-Host "ГОТОВО: $PWD\dist\TimerTask.exe" -ForegroundColor Green }
else { Write-Host "ОШИБКА сборки" -ForegroundColor Red }
