#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Таймер действий — небольшая утилита с окном (Tkinter).

Задаёте время (секунды или минуты), выбираете действие и жмёте «Старт».
По истечении таймера выполняется выбранное действие.

Действия:
  - Предпросмотр (только показать результат, ничего не трогает)  <- безопасно для теста
  - Завершение работы системы (shutdown / poweroff)
  - Выход из системы (logout / завершение сеанса)
  - Спящий режим
  - Перезагрузка
  - Пользовательская команда

Режим --dry-run печатает команду, которую собирается выполнить,
но НЕ выполняет её — удобно тестировать в песочнице.
"""

import sys
import time
import shutil
import platform
import subprocess
from datetime import datetime, timedelta

try:
    import tkinter as tk
    from tkinter import ttk, messagebox
    HAS_TK = True
except Exception:
    HAS_TK = False


# ---------------------------------------------------------------------------
# Защита вывода для EXE-сборки (--windowed): в pythonw-режиме sys.stdout/
# sys.stderr равны None, и любой print() уронил бы приложение. Подменяем их
# безопасными заглушками, если реальный поток недоступен.
# ---------------------------------------------------------------------------
def _ensure_streams():
    class _Null:
        def write(self, *a, **k): return 0
        def flush(self): pass
        def fileno(self): raise OSError("no stream")
        @property
        def encoding(self): return "utf-8"
        isatty = lambda self: False
    for name in ("stdout", "stderr"):
        if getattr(sys, name, None) is None:
            try:
                setattr(sys, name, _Null())
            except Exception:
                pass


_ensure_streams()


# ---------------------------------------------------------------------------
# Определение платформы и подходящих команд
# ---------------------------------------------------------------------------

def detect_commands():
    """Возвращает словарь: название действия -> shell-команда для текущей ОС."""
    system = platform.system()  # 'Linux', 'Windows', 'Darwin'
    cmds = {}

    def has(cmd):
        return shutil.which(cmd) is not None

    if system == "Linux":
        use_systemd = has("systemctl")
        if use_systemd:
            cmds["Выключение ПК"] = "systemctl poweroff"
            cmds["Выход из системы"] = "loginctl terminate-user $USER"
            cmds["Спящий режим"] = "systemctl suspend"
            cmds["Перезагрузка"] = "systemctl reboot"
        else:
            cmds["Выключение ПК"] = "shutdown -h now"
            cmds["Выход из системы"] = "pkill -u $USER -TERM"
            cmds["Спящий режим"] = "rtcwake -m mem -g 0 || echo 'suspend недоступен'"
            cmds["Перезагрузка"] = "reboot"
    elif system == "Darwin":
        cmds["Выключение ПК"] = "osascript -e 'tell app \"System Events\" to shut down'"
        cmds["Выход из системы"] = "osascript -e 'tell app \"System Events\" to log out'"
        cmds["Спящий режим"] = "pmset sleepnow"
        cmds["Перезагрузка"] = "osascript -e 'tell app \"System Events\" to restart'"
    elif system == "Windows":
        cmds["Выключение ПК"] = "shutdown /s /t 0"
        cmds["Выход из системы"] = "shutdown /l"
        cmds["Спящий режим"] = "rundll32.exe powrprof.dll,SetSuspendState 0,1,0"
        cmds["Перезагрузка"] = "shutdown /r /t 0"
    else:
        cmds["Выключение ПК"] = "echo 'Неизвестная платформа: выключение недоступно'"
        cmds["Выход из системы"] = "echo 'Неизвестная платформа: выход недоступен'"
        cmds["Спящий режим"] = "echo 'Неизвестная платформа: сон недоступен'"
        cmds["Перезагрузка"] = "echo 'Неизвестная платформа: перезагрузка недоступна'"

    # Специальное безопасное действие для теста
    cmds["Предпросмотр (безопасно)"] = "echo '[ПРЕДПРОСМОТР] действие выполнено бы здесь'"
    return cmds


ACTION_ORDER = [
    "Предпросмотр (безопасно)",
    "Выключение ПК",
    "Выход из системы",
    "Спящий режим",
    "Перезагрузка",
    "Пользовательская команда",
]


# ---------------------------------------------------------------------------
# Ядро: планирование и выполнение
# ---------------------------------------------------------------------------

class ActionRunner:
    def __init__(self, dry_run=False):
        self.dry_run = dry_run
        self.commands = detect_commands()
        self._proc = None

    def command_for(self, action, custom=""):
        if action == "Пользовательская команда":
            return custom.strip()
        return self.commands.get(action, "")

    def run(self, action, custom=""):
        cmd = self.command_for(action, custom)
        if not cmd:
            raise ValueError(f"Нет команды для действия: {action}")
        if self.dry_run:
            print(f"[DRY-RUN] будет выполнена команда: {cmd}")
            return cmd
        print(f"[EXEC] выполняю: {cmd}")
        if platform.system() == "Windows":
            # Windows: запуск без лишнего консольного окна (важно для EXE-сборки,
            # где stdout/stderr могут отсутствовать).
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            self._proc = subprocess.Popen(
                cmd, shell=True,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=creationflags,
            )
            return cmd
        self._proc = subprocess.Popen(
            cmd, shell=True,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
        )
        out, _ = self._proc.communicate()
        if out:
            print(out.strip())
        return cmd


# ---------------------------------------------------------------------------
# Консольный интерфейс (для теста в песочнице без GUI)
# ---------------------------------------------------------------------------

def parse_duration(text):
    """Принимает '90', '5m', '1h30m', '01:30:00', '90s' -> секунды (int)."""
    text = text.strip().lower().replace(" ", "")
    if not text:
        raise ValueError("пустое значение")
    # HH:MM:SS или MM:SS
    if ":" in text:
        parts = [int(p) for p in text.split(":")]
        while len(parts) < 3:
            parts.insert(0, 0)
        h, m, s = parts[-3], parts[-2], parts[-1]
        return h * 3600 + m * 60 + s
    # суффиксы
    total = 0
    num = ""
    matched = False
    for ch in text:
        if ch.isdigit():
            num += ch
        elif ch in ("s", "m", "h", "д", "м", "ч"):
            if not num:
                raise ValueError(f"не понял: {text}")
            n = int(num)
            unit = {"s": 1, "m": 60, "h": 3600, "д": 86400, "м": 60, "ч": 3600}[ch]
            total += n * unit
            num = ""
            matched = True
        else:
            raise ValueError(f"неизвестный символ '{ch}'")
    if num and not matched:
        # просто число -> секунды
        return int(num)
    if not matched:
        raise ValueError(f"не понял: {text}")
    return total


def cli_mode(argv):
    """python timer_task.py --cli --time 10 --action 'Предпросмотр (безопасно)' [--dry-run]"""
    opts = {"time": "10", "action": "Предпросмотр (безопасно)", "custom": "", "list": False}
    dry = "--dry-run" in argv
    it = iter(range(len(argv)))
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--time" and i + 1 < len(argv):
            opts["time"] = argv[i + 1]; i += 2; continue
        if a == "--action" and i + 1 < len(argv):
            opts["action"] = argv[i + 1]; i += 2; continue
        if a == "--custom" and i + 1 < len(argv):
            opts["custom"] = argv[i + 1]; i += 2; continue
        i += 1

    runner = ActionRunner(dry_run=dry)

    if opts["list"]:
        for name in ACTION_ORDER:
            print(f"  - {name}: {runner.command_for(name)}")
        return 0

    secs = parse_duration(opts["time"])
    target = datetime.now() + timedelta(seconds=secs)
    print(f"⏳ Таймер: {secs} сек. Действие: «{opts['action']}»")
    print(f"   Цель: {target.strftime('%H:%M:%S')}")
    end = time.time() + secs
    while time.time() < end:
        left = int(end - time.time())
        print(f"\r   осталось {left:>4} сек ...", end="", flush=True)
        time.sleep(0.5)
    print("\r   время вышло!          ")
    cmd = runner.run(opts["action"], opts["custom"])
    print(f"✔ Готово. Команда: {cmd}")
    return 0


# ---------------------------------------------------------------------------
# Графический интерфейс (Tkinter)
#   1) Окно настройки -> после «Старт» плавно исчезает (fade-out)
#   2) Полноэкранный оверлей с БОЛЬШИМИ КРАСНЫМИ цифрами обратного отсчёта
#   3) По истечении — подтверждение и выполнение действия; «Esc» — отмена
# ---------------------------------------------------------------------------

BG_DARK = "#0d0d0d"
FG_RED = "#ff1f1f"


def _fmt_hms(left):
    h, rem = divmod(int(left), 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def _fit_font(label, text, base_size):
    """Подбирает размер шрифта так, чтобы текст помещался в экран."""
    size = base_size
    while size > 24:
        label.config(font=("DejaVu Sans Mono", size, "bold"))
        label.update_idletasks()
        w = label.winfo_reqwidth()
        if w < label.winfo_screenwidth() * 0.9:
            break
        size -= 8
    return size


def fade_window(win, on_done, step_ms=25, delta=0.06):
    """Плавное затухание окна (alpha 1.0 -> 0.0), затем on_done()."""
    try:
        win.attributes("-alpha", 1.0)
    except tk.TclError:
        on_done()
        return

    alpha = [1.0]

    def do_fade():
        alpha[0] -= delta
        if alpha[0] <= 0:
            try:
                win.withdraw()
            except tk.TclError:
                pass
            on_done()
            return
        try:
            win.attributes("-alpha", max(0.0, alpha[0]))
        except tk.TclError:
            on_done()
            return
        win.after(step_ms, do_fade)

    do_fade()


def gui_mode():
    if not HAS_TK:
        print("Tkinter недоступен в этой среде. Используйте --cli.")
        print("Установите: sudo apt-get install python3-tk")
        return 1

    runner = ActionRunner(dry_run=False)

    # ---------------- окно настройки ----------------
    root = tk.Tk()
    root.title("Таймер действий — настройка")
    root.geometry("440x330")
    root.resizable(False, False)

    status_var = tk.StringVar(value="Готово")

    frm = ttk.Frame(root, padding=14)
    frm.pack(fill="both", expand=True)

    ttk.Label(frm, text="Время (сек, 5m, 1h30m, MM:SS):").grid(row=0, column=0, sticky="w")
    ent_time = ttk.Entry(frm, width=18)
    ent_time.grid(row=0, column=1, sticky="we", pady=4)
    ent_time.insert(0, "60")

    ttk.Label(frm, text="Действие:").grid(row=1, column=0, sticky="w")
    cb_action = ttk.Combobox(frm, values=ACTION_ORDER, state="readonly", width=26)
    cb_action.grid(row=1, column=1, sticky="we", pady=4)
    cb_action.set(ACTION_ORDER[0])

    ttk.Label(frm, text="Команда (если «Пользовательская»):").grid(row=2, column=0, sticky="w")
    ent_custom = ttk.Entry(frm, width=30)
    ent_custom.grid(row=2, column=1, sticky="we", pady=4)

    ttk.Label(
        frm,
        text="После «Старт» это окно плавно исчезнет,\n"
             "а на экране появится большой таймер с красными цифрами.\n"
             "Esc или клик мышью — отменить.",
        foreground="#666", justify="left",
    ).grid(row=3, column=0, columnspan=2, pady=8, sticky="w")

    btn_row = ttk.Frame(frm)
    btn_row.grid(row=4, column=0, columnspan=2)
    btn_start = ttk.Button(btn_row, text="▶ Старт")
    btn_start.pack(side="left", padx=6)
    ttk.Label(frm, textvariable=status_var, foreground="#666").grid(
        row=5, column=0, columnspan=2, pady=4, sticky="w")

    # ---------------- полноэкранный таймер ----------------
    overlay = tk.Toplevel(root)
    overlay.title("Таймер")
    overlay.configure(bg=BG_DARK)
    overlay.overrideredirect(True)          # без рамки и заголовка
    overlay.attributes("-fullscreen", True)
    overlay.withdraw()                      # пока скрыт

    action_lbl = tk.Label(overlay, text="", bg=BG_DARK, fg="#bbbbbb",
                          font=("DejaVu Sans", 20))
    action_lbl.place(relx=0.5, rely=0.18, anchor="center")

    hint_lbl = tk.Label(overlay, text="Esc или клик — отменить таймер",
                        bg=BG_DARK, fg="#555555", font=("DejaVu Sans", 13))
    hint_lbl.place(relx=0.5, rely=0.88, anchor="center")

    time_lbl = tk.Label(overlay, text="00:00", bg=BG_DARK, fg=FG_RED,
                        font=("DejaVu Sans Mono", 200, "bold"))
    time_lbl.place(relx=0.5, rely=0.5, anchor="center")

    state = {"after_id": None, "end_ts": 0, "running": False,
             "base_font": 200, "last_left": -1}

    def show_overlay():
        """Оверлей появляется плавно (fade-in)."""
        overlay.deiconify()
        overlay.lift()
        overlay.focus_force()
        try:
            overlay.attributes("-alpha", 0.0)
        except tk.TclError:
            pass
        a = [0.0]

        def do_in():
            a[0] += 0.08
            if a[0] >= 1.0:
                try:
                    overlay.attributes("-alpha", 1.0)
                except tk.TclError:
                    pass
                start_countdown()
                return
            try:
                overlay.attributes("-alpha", a[0])
            except tk.TclError:
                start_countdown()
                return
            overlay.after(25, do_in)

        do_in()

    def start_countdown():
        state["running"] = True
        state["last_left"] = -1
        tick()

    def tick():
        if not state["running"]:
            return
        left = max(0, int(round(state["end_ts"] - time.time())))
        if left != state["last_left"]:
            state["last_left"] = left
            txt = _fmt_hms(left)
            time_lbl.config(text=txt)
            _fit_font(time_lbl, txt, state["base_font"])
            # последние 10 секунд — мигание ярче/тусклее
            if left <= 10 and left > 0:
                time_lbl.config(fg="#ff1f1f" if left % 2 == 0 else "#7a0f0f")
        if left <= 0:
            fire()
            return
        state["after_id"] = overlay.after(200, tick)

    def back_to_settings(msg=None):
        """Возврат из оверлея в окно настройки."""
        state["running"] = False
        if state["after_id"]:
            try:
                overlay.after_cancel(state["after_id"])
            except tk.TclError:
                pass
            state["after_id"] = None
        overlay.withdraw()
        root.deiconify()
        try:
            root.attributes("-alpha", 1.0)
        except tk.TclError:
            pass
        root.lift()
        root.focus_force()
        if msg:
            status_var.set(msg)

    def cancel_timer(_event=None):
        if not state["running"]:
            return
        back_to_settings("⏹ Таймер отменён")

    def fire():
        state["running"] = False
        action = cb_action.get()
        custom = ent_custom.get()
        time_lbl.config(text="00:00", fg=FG_RED)
        cmd = runner.command_for(action, custom)

        if action == "Предпросмотр (безопасно)":
            # сразу показываем результат и возвращаемся в окно настройки
            overlay.after(1500, lambda: back_to_settings(f"✔ Предпросмотр выполнен: {cmd}"))
            return

        # опасные действия — подтверждение прямо поверх оверлея
        ok = messagebox.askyesno(
            "Подтверждение",
            f"Время вышло!\n\nВыполнить команду?\n\n{cmd}\n\n(Действие: {action})",
            parent=overlay)
        if ok:
            try:
                runner.run(action, custom)
                back_to_settings(f"✔ Выполнено: {action}")
            except Exception as e:
                back_to_settings(f"✖ Ошибка: {e}")
        else:
            back_to_settings("Отменено пользователем")

    def start():
        raw = ent_time.get().strip()
        try:
            secs = parse_duration(raw)
        except Exception as e:
            messagebox.showerror("Ошибка времени", str(e), parent=root)
            return
        if secs <= 0:
            messagebox.showerror("Ошибка", "Время должно быть > 0", parent=root)
            return
        action = cb_action.get()

        # сначала показываем оверлей (полноэкранный), затем гасим окно настройки —
        # так на экране нет «пустого» момента и цифры сразу большие
        time_lbl.config(text=_fmt_hms(secs), fg=FG_RED)
        action_lbl.config(text=f"⏳ Действие: {action}")
        state["base_font"] = _fit_font(time_lbl, _fmt_hms(secs), 200)
        overlay.deiconify()
        overlay.attributes("-alpha", 1.0)
        overlay.lift()
        overlay.update_idletasks()
        state["base_font"] = _fit_font(time_lbl, _fmt_hms(secs), 200)
        state["end_ts"] = time.time() + secs

        def after_fade():
            overlay.focus_force()
            start_countdown()

        fade_window(root, after_fade)

    overlay.bind("<Escape>", cancel_timer)
    overlay.bind("<Button-1>", cancel_timer)
    btn_start.config(command=start)

    root.protocol("WM_DELETE_WINDOW", lambda: (overlay.destroy(), root.destroy()))
    root.mainloop()
    return 0


# ---------------------------------------------------------------------------

def main():
    argv = sys.argv[1:]
    if "--cli" in argv or not HAS_TK:
        return cli_mode(argv)
    return gui_mode()


if __name__ == "__main__":
    raise SystemExit(main())
